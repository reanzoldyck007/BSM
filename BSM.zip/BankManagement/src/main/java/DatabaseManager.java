import java.sql.*;
import java.sql.Connection;
import javax.swing.JOptionPane;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
public class DatabaseManager {
    private Connection connection;
    private String URL;
    private String USER;
    private String PASSWORD;

    public DatabaseManager(String url, String user, String password) {
        this.URL = url;
        this.USER = user;
        this.PASSWORD = password;
        try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        this.connection = DriverManager.getConnection(this.URL, this.USER, this.PASSWORD);
    } catch (SQLException | ClassNotFoundException e) {
        e.printStackTrace();
        // Handle exceptions properly (e.g., log or display an error message)
    }
    }
    
    public boolean authenticate(String accountId, String password) {
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);

        String sql = "SELECT * FROM bankaccounts WHERE account_id = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, accountId);

        ResultSet resultSet = statement.executeQuery();

        boolean isAuthenticated = false;

        if (resultSet.next()) {
            String storedPassword = resultSet.getString("password");
            isAuthenticated = checkPassword(password, storedPassword);
        }
        resultSet.close();
        statement.close();
        connection.close();

        return isAuthenticated;

    } catch (SQLException | ClassNotFoundException e) {
        e.printStackTrace();
        // Handle exceptions properly (e.g., log or display an error message)
        return false;
    }
}

// Method to hash the password and compare with the stored hash
private boolean checkPassword(String password, String storedPassword) {
    try {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashedPassword = md.digest(password.getBytes());

        // Convert byte array to hexadecimal string
        StringBuilder sb = new StringBuilder();
        for (byte b : hashedPassword) {
            sb.append(String.format("%02x", b));
        }

        String hashedEnteredPassword = sb.toString();

        return hashedEnteredPassword.equals(storedPassword);

    } catch (NoSuchAlgorithmException e) {
        e.printStackTrace();
        // Handle hashing algorithm exception
        return false;
    }
}

    public void saveToDatabase(String firstName, String middleName, String lastName, String email, String phone, String gender, String city, String province, String barangay, String password) {
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
        int accountNumber = generateAccountNumber();
        if (checkEmailExist(email)) {
        JOptionPane.showMessageDialog(null, "Email is already in use.");
        return;
        
    }
    if (checkNumberExist(phone)) {
        JOptionPane.showMessageDialog(null, "Phone number is already in use.");
        return;
    }
        double initialBalance = 0.00;
        String hashedPassword = hashPassword(password);
        String sql = "INSERT INTO bankaccounts (account_id, first_name, last_name, email, phone, gender, city, province, barangay, password, balance) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement statement = connection.prepareStatement(sql);

        statement.setInt(1, accountNumber);
        statement.setString(2, firstName);
        statement.setString(3, lastName);
        statement.setString(4, email);
        statement.setString(5, phone);
        statement.setString(6, gender);
        statement.setString(7, city);
        statement.setString(8, province);
        statement.setString(9, barangay);
        statement.setString(10, hashedPassword); 
        statement.setDouble(11, initialBalance); 

        statement.executeUpdate();

        statement.close();
        connection.close();

        // Display account number and password in a dialog (if needed)
        JOptionPane.showMessageDialog(null, "Account created successfully!\nAccount Number: " + accountNumber + "\nPassword: " + password);

    } catch (SQLException | ClassNotFoundException e) {
        e.printStackTrace();
        // Handle exceptions properly (e.g., log or display an error message)
    }
}
public boolean checkEmailExist(String email) {
    String query = "SELECT COUNT(*) AS count FROM bankaccounts WHERE email = ?";
    try {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        PreparedStatement pstmt = conn.prepareStatement(query);
        pstmt.setString(1, email);
        ResultSet resultSet = pstmt.executeQuery();
        if (resultSet.next()) {
            int count = resultSet.getInt("count");
            return count > 0;
        }
        resultSet.close();
        pstmt.close();
        conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
        // Handle exceptions or return a default value
    }
    return false;
}

public boolean checkNumberExist(String phoneNumber) {
    String query = "SELECT COUNT(*) AS count FROM bankaccounts WHERE phone = ?";
    try {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        PreparedStatement pstmt = conn.prepareStatement(query);
        pstmt.setString(1, phoneNumber);
        ResultSet resultSet = pstmt.executeQuery();
        if (resultSet.next()) {
            int count = resultSet.getInt("count");
            return count > 0;
        }
        resultSet.close();
        pstmt.close();
        conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
        // Handle exceptions or return a default value
    }
    return false;
}

// Method to hash the password
private String hashPassword(String password) {
    try {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashedPassword = md.digest(password.getBytes());

        // Convert byte array to hexadecimal string
        StringBuilder sb = new StringBuilder();
        for (byte b : hashedPassword) {
            sb.append(String.format("%02x", b));
        }

        return sb.toString();

    } catch (NoSuchAlgorithmException e) {
        e.printStackTrace();
        // Handle hashing algorithm exception
        return null;
    }
}

public boolean depositToAccount(String accountId, double amount) {
    String depositQuery = "UPDATE bankaccounts SET balance = balance + ? WHERE account_id = ?";
    String logDepositQuery = "INSERT INTO transactions (sender_account_id, transaction_type, amount) VALUES (?, 'Deposit', ?)";

    try {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        conn.setAutoCommit(false);

        // Update account balance
        PreparedStatement depositStmt = conn.prepareStatement(depositQuery);
        depositStmt.setDouble(1, amount);
        depositStmt.setString(2, accountId);
        int rowsUpdated = depositStmt.executeUpdate();

        if (rowsUpdated > 0) {
            // Log deposit transaction
            PreparedStatement logStmt = conn.prepareStatement(logDepositQuery);
            logStmt.setString(1, accountId);
            logStmt.setDouble(2, amount);
            logStmt.executeUpdate();

            conn.commit();

            // Get updated balance
            double updatedBalance = getAccountBalance(accountId);
            System.out.println("Deposit successful for Account ID: " + accountId);
            System.out.println("Updated balance: " + updatedBalance);
            return true;
        } else {
            conn.rollback();
            System.out.println("Deposit failed for Account ID: " + accountId);
            return false;
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}





public boolean recordTransaction(String accountId, String transactionType, double amount) {
    Connection conn = null;
    PreparedStatement stmt = null;

    try {
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "admin", "wiggd872qaymu");
        String query = "INSERT INTO transaction_history (account_id, transaction_type, amount) VALUES (?, ?, ?)";
        stmt = conn.prepareStatement(query);
        stmt.setString(1, accountId); // Use the provided account ID here
        stmt.setString(2, transactionType);
        stmt.setDouble(3, amount);
        int rowsAffected = stmt.executeUpdate();

        return rowsAffected > 0;
    } catch (SQLException e) {
        e.printStackTrace(); // Handle or log the exception as required
        return false;
    } finally {
        // Close resources in a finally block
        try {
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception as required
        }
    }
}


public boolean sendToAccount(String receiverAccountId, double amount) {
    String creditQuery = "UPDATE bankaccounts SET balance = balance + ? WHERE account_id = ?";
    try {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        conn.setAutoCommit(false);

        PreparedStatement creditStmt = conn.prepareStatement(creditQuery);
        creditStmt.setDouble(1, amount);
        creditStmt.setString(2, receiverAccountId);
        int rowsUpdated = creditStmt.executeUpdate();

        if (rowsUpdated > 0) {
            conn.commit();
            return true;
        } else {
            conn.rollback();
            return false;
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

public boolean withdrawFromAccount(String accountId, double amount) {
    String withdrawQuery = "UPDATE bankaccounts SET balance = balance - ? WHERE account_id = ?";
    String logWithdrawalQuery = "INSERT INTO transactions (sender_account_id, transaction_type, amount) VALUES (?, 'Withdrawal', ?)";


    try {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        conn.setAutoCommit(false);

        // Check if withdrawal is valid
        double currentBalance = getAccountBalance(accountId);
        if (amount <= 0 || amount > currentBalance) {
            conn.rollback();
            System.out.println("Withdrawal failed for Account ID: " + accountId + ". Insufficient funds or invalid amount.");
            return false;
        }
        
        // Update account balance
        PreparedStatement withdrawStmt = conn.prepareStatement(withdrawQuery);
        withdrawStmt.setDouble(1, amount);
        withdrawStmt.setString(2, accountId);
        int rowsUpdated = withdrawStmt.executeUpdate();

        if (rowsUpdated > 0) {
            // Log withdrawal transaction
            PreparedStatement logStmt = conn.prepareStatement(logWithdrawalQuery);
            logStmt.setString(1, accountId);
            logStmt.setDouble(2, amount);
            logStmt.executeUpdate();

            conn.commit();

            double updatedBalance = getAccountBalance(accountId);
            System.out.println("Withdrawal successful for Account ID: " + accountId);
            System.out.println("Updated balance: " + updatedBalance);
            return true;
        } else {
            conn.rollback();
            System.out.println("Withdrawal failed for Account ID: " + accountId);
            return false;
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}


public boolean sentFromAccount(String senderAccountId, double amount, String receiverAccountId) {
    String debitQuery = "UPDATE bankaccounts SET balance = balance - ? WHERE account_id = ?";
    try {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        conn.setAutoCommit(false);

        PreparedStatement debitStmt = conn.prepareStatement(debitQuery);
        debitStmt.setDouble(1, amount);
        debitStmt.setString(2, senderAccountId);
        int rowsUpdated = debitStmt.executeUpdate();

        if (rowsUpdated > 0) {
            conn.commit();
            return true;
        } else {
            conn.rollback();
            return false;
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}



public double getAccountBalance(String accountId) throws SQLException{
    String query = "SELECT balance FROM bankaccounts WHERE account_id = ?";
    
    try {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        PreparedStatement pstmt = conn.prepareStatement(query);
        
        pstmt.setString(1, accountId);
        ResultSet resultSet = pstmt.executeQuery();
        
        double balance = 0.0;
        if (resultSet.next()) {
            balance = resultSet.getDouble("balance");
        }
        
        resultSet.close();
        pstmt.close();
        conn.close();
        
        return balance;
    } catch (SQLException e) {
        e.printStackTrace();
        return 0.0; // Return a default value or handle the error accordingly
    }
}
public int getAccountId(String accountId) throws SQLException{
    String query = "SELECT accountid FROM bankaccounts WHERE account_id = ?";
    
    try {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        PreparedStatement pstmt = conn.prepareStatement(query);
        
        pstmt.setString(1, accountId);
        ResultSet resultSet = pstmt.executeQuery();
        
        int balance1 = 0;
        if (resultSet.next()) {
            balance1 = resultSet.getInt("accountid");
        }
        
        resultSet.close();
        pstmt.close();
        conn.close();
        
        return balance1;
    } catch (SQLException e) {
        e.printStackTrace();
        return 0; // Return a default value or handle the error accordingly
    }
}

public ArrayList<Object[]> getTransactionHistory(String accountId) {
    ArrayList<Object[]> transactionData = new ArrayList<>();

    try {
        Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
        String sql = "SELECT * FROM transactions WHERE sender_account_id = ? OR receiver_account_id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, accountId);
        preparedStatement.setString(2, accountId);

        ResultSet resultSet = preparedStatement.executeQuery();

        while (resultSet.next()) {
            int transactionID = resultSet.getInt("transaction_id");
            String transactionType = resultSet.getString("transaction_type");
            double amount = resultSet.getDouble("amount");
            String senderID = resultSet.getString("sender_account_id");
            String receiverID = resultSet.getString("receiver_account_id");
            String timestamp = resultSet.getString("timestamp");

            String counterParty;
            String displayTransactionType;

            // Handle null transactionType
            if (transactionType == null) {
                // You can skip or handle these cases based on your application's logic
                continue;
            }

            if (senderID.equals(accountId)) {
                counterParty = receiverID != null ? receiverID : "Unknown";
                displayTransactionType = "Sent";
            } else if (receiverID.equals(accountId)) {
                counterParty = senderID != null ? senderID : "Unknown";
                displayTransactionType = "Received";
            } else {
                // Transactions not involving the logged-in account
                continue;
            }

            if (transactionType.equals("Withdrawal") && senderID.equals(accountId)) {
                displayTransactionType = "Withdraw";
                counterParty = accountId; // Set the counterParty to the account ID logged in for withdrawals
            }

            String displayCounterParty = counterParty.equals(accountId) ? accountId : counterParty;

            Object[] transaction = { transactionID, displayTransactionType, amount, displayCounterParty, timestamp };
            transactionData.add(transaction);
        }

        resultSet.close();
        preparedStatement.close();
        connection.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return transactionData;
}















public String[] getUserDetails(String accountId) throws SQLException {
    String query = "SELECT first_name, last_name, email, phone, barangay, province, city, password FROM bankaccounts WHERE account_id = ?";
    String[] userDetails = new String[8];

    try {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        PreparedStatement pstmt = conn.prepareStatement(query);

        pstmt.setString(1, accountId);
        ResultSet resultSet = pstmt.executeQuery();

        if (resultSet.next()) {
            userDetails[0] = resultSet.getString("first_name");
            userDetails[1] = resultSet.getString("last_name");
            userDetails[2] = resultSet.getString("email");
            userDetails[3] = resultSet.getString("phone");
            userDetails[4] = resultSet.getString("barangay");
            userDetails[5] = resultSet.getString("province");
            userDetails[6] = resultSet.getString("city");
            userDetails[7] = resultSet.getString("password");
        }

        resultSet.close();
        pstmt.close();
        conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
        // Handle exceptions or return default values
    }

    return userDetails;
}
public boolean updatePassword(String accountId, String newPassword) {
    try {
        Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
        String query = "UPDATE bankaccounts SET password = ? WHERE account_id = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        
        // Hash the new password before updating
        String hashedPassword = hashPassword(newPassword);
        
        statement.setString(1, hashedPassword);
        statement.setString(2, accountId);

        int rowsUpdated = statement.executeUpdate();

        statement.close();
        connection.close();

        return rowsUpdated > 0; // Returns true if the password was updated successfully

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
public int getTotalRegisteredAccounts() {
        int totalAccounts = 0;
        try {
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            Statement statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery("SELECT COUNT(*) AS total FROM bankaccounts");
            if (resultSet.next()) {
                totalAccounts = resultSet.getInt("total");
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions or return a default value
        }
        return totalAccounts;
    }

    public double getTotalDeposits() {
    double totalDeposits = 0.0;

    try {
        Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
        String sql = "SELECT SUM(amount) AS total FROM transactions WHERE transaction_type = 'Deposit'";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            totalDeposits = resultSet.getDouble("total");
        }

        resultSet.close();
        preparedStatement.close();
        connection.close();
    } catch (SQLException e) {
        e.printStackTrace();
        // Handle exceptions
    }

    return totalDeposits;
}


public double getTotalWithdrawals() {
    double totalWithdrawals = 0.0;

    try {
        Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
        String sql = "SELECT SUM(amount) AS total FROM transactions WHERE transaction_type = 'Withdrawal'";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            totalWithdrawals = resultSet.getDouble("total");
        }

        resultSet.close();
        preparedStatement.close();
        connection.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return totalWithdrawals;
}



    public ArrayList<Object[]> getAccountDetails() {
        ArrayList<Object[]> accountDetails = new ArrayList<>();
        try {
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            Statement statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery("SELECT account_id, first_name, last_name, balance FROM bankaccounts");
            while (resultSet.next()) {
                Object[] row = {
                        resultSet.getString("account_id"),
                        resultSet.getString("first_name"),
                        resultSet.getString("last_name"),
                        resultSet.getDouble("balance")
                };
                accountDetails.add(row);
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions or return an empty list
        }
        return accountDetails;
    }
public boolean userExists(String accountId) {
    try {
        Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);

        String sql = "SELECT COUNT(*) AS count FROM bankaccounts WHERE account_id = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, accountId);

        ResultSet resultSet = statement.executeQuery();

        int count = 0;

        if (resultSet.next()) {
            count = resultSet.getInt("count");
        }

        // Close resources
        resultSet.close();
        statement.close();
        connection.close();

        return count > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        // Handle exceptions properly (e.g., log or display an error message)
        return false;
    }
}

public ArrayList<Object[]> getTransactionHistoryForAdmin() {
    String query = "SELECT transaction_id, sender_account_id, receiver_account_id, transaction_type, amount, timestamp FROM transactions";
    ArrayList<Object[]> transactionData = new ArrayList<>();

    try {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        PreparedStatement pstmt = conn.prepareStatement(query);
        ResultSet resultSet = pstmt.executeQuery();

        while (resultSet.next()) {
            int transactionID = resultSet.getInt("transaction_id");
            String senderID = resultSet.getString("sender_account_id");
            String receiverID = resultSet.getString("receiver_account_id");
            String transactionType = resultSet.getString("transaction_type");
            double amount = resultSet.getDouble("amount");
            String timestamp = resultSet.getString("timestamp");

            Object[] transaction = { transactionID, senderID, receiverID, transactionType, amount, timestamp };
            transactionData.add(transaction);
        }

        resultSet.close();
        pstmt.close();
        conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
        // Handle exceptions or return an empty list
    }

    return transactionData;
}


public boolean depositFunction(String accountId, double amount) {
    if (accountId == null || amount <= 0) {
        System.out.println("Invalid parameters provided for deposit.");
        return false;
    }

    String depositQuery = "UPDATE bankaccounts SET balance = balance + ? WHERE account_id = ?";
    boolean transactionSaved = false; // Initialize outside the try-catch block

    try {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        PreparedStatement depositStmt = conn.prepareStatement(depositQuery);
        depositStmt.setDouble(1, amount);
        depositStmt.setString(2, accountId);

        int rowsUpdated = depositStmt.executeUpdate();
        
        if (rowsUpdated > 0) {
            transactionSaved = saveTransaction("ADMIN", "ADMIN", accountId, amount, "Deposit");

            // Check if the transaction was successfully saved
            if (transactionSaved) {
                // Log a message or handle success as needed
                System.out.println("Transaction saved successfully.");
            } else {
                // Log a message or handle failure as needed
                System.out.println("Failed to save transaction.");
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }

    return transactionSaved;
}



public boolean saveTransaction(String loggedInAccountId, String senderAccountId, String receiverAccountId, double amount, String transactionType) {
    if (senderAccountId == null || receiverAccountId == null || loggedInAccountId == null || transactionType == null) {
        System.out.println("Invalid parameters provided for transaction.");
        return false;
    }

    String insertTransactionQuery = "INSERT INTO transactions (sender_account_id, receiver_account_id, amount, transaction_type) VALUES (?, ?, ?, ?)";
    try {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        PreparedStatement insertStmt = conn.prepareStatement(insertTransactionQuery);
        insertStmt.setString(1, senderAccountId);
        insertStmt.setString(2, receiverAccountId);
        insertStmt.setDouble(3, amount);
        insertStmt.setString(4, transactionType);

        int rowsInserted = insertStmt.executeUpdate();

        return rowsInserted > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
public boolean adminDeposit(String receiverAccountId, double amount) {
    String updateReceiverBalanceQuery = "UPDATE bankaccounts SET balance = balance + ? WHERE account_id = ?";
    
    try {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        PreparedStatement receiverStatement = conn.prepareStatement(updateReceiverBalanceQuery);
        receiverStatement.setDouble(1, amount);
        receiverStatement.setString(2, receiverAccountId);
        int receiverUpdateCount = receiverStatement.executeUpdate();

        return receiverUpdateCount > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}







    private int generateAccountNumber() {
        return 1000000 + (int) (Math.random() * 9000000);
    }
}

