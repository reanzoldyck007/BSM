public class Transactions {
    private int transactionID;
    private String type;
    private double amount;
    private String relatedAccountID;
    private String timestamp;

    // Constructors
    public Transactions() {
        // Default constructor
    }

    public Transactions(int transactionID, String type, double amount, String relatedAccountID, String timestamp) {
        this.transactionID = transactionID;
        this.type = type;
        this.amount = amount;
        this.relatedAccountID = relatedAccountID;
        this.timestamp = timestamp;
    }

    // Getters and setters
    public int getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(int transactionID) {
        this.transactionID = transactionID;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getRelatedAccountID() {
        return relatedAccountID;
    }

    public void setRelatedAccountID(String relatedAccountID) {
        this.relatedAccountID = relatedAccountID;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}
