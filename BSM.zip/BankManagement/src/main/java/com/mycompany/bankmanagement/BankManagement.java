/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bankmanagement;

/**
 *
 * @author ASUS TUF GAMING
 */
public class BankManagement {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
